#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."

echo "Containers:"
docker ps --filter 'name=lira-ai-' --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

echo
echo "Backend health:"
curl -fsS http://127.0.0.1:${BACKEND_PORT:-8000}/health/live || true

echo
echo "Frontend status:"
curl -fsSI http://127.0.0.1:${FRONTEND_PORT:-3000}/ | head -n 1 || true
