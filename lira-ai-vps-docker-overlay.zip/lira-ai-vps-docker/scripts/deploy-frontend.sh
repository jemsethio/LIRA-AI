#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."

if [[ ! -f .env.vps ]]; then
  echo "Missing .env.vps. Copy .env.vps.example to .env.vps and edit it." >&2
  exit 1
fi

docker compose --env-file .env.vps -f compose.frontend.yml up -d --build --remove-orphans
docker compose --env-file .env.vps -f compose.frontend.yml ps
