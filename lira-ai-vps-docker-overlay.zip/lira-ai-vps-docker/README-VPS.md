# LIRA-AI independent VPS containers

This overlay adds production Docker builds for the existing `frontend/` and `backend/` directories. Each service has its own Compose file and can be deployed independently.

## Install the overlay

Copy the contents of this folder into the root of a clone of `jemsethio/LIRA-AI`. The resulting layout should include:

```text
LIRA-AI/
├── backend/
│   ├── Dockerfile.prod
│   └── .dockerignore
├── frontend/
│   ├── Dockerfile.prod
│   └── .dockerignore
├── compose.backend.yml
├── compose.frontend.yml
├── compose.full.yml
├── .env.vps.example
├── nginx/lira-ai.conf
└── scripts/
```

## Configure

```bash
cd /opt/LIRA-AI
cp .env.vps.example .env.vps
nano .env.vps
```

At minimum, replace these values:

```dotenv
FRONTEND_URL=https://app.your-domain.com
NEXT_PUBLIC_API_URL=https://api.your-domain.com
CORS_ORIGINS=["https://app.your-domain.com"]
```

`NEXT_PUBLIC_API_URL` is baked into the browser bundle during `docker build`. Rebuild the frontend whenever this URL changes.

## Deploy independently

Backend only:

```bash
./scripts/deploy-backend.sh
curl http://127.0.0.1:8000/health/live
```

Frontend only:

```bash
./scripts/deploy-frontend.sh
curl -I http://127.0.0.1:3000/
```

Both services:

```bash
./scripts/deploy-all.sh
```

The services intentionally have no `depends_on` relationship. The frontend calls the backend through `NEXT_PUBLIC_API_URL`, so they may be restarted or deployed separately.

## Nginx and HTTPS

Edit `nginx/lira-ai.conf` and replace `app.example.com` and `api.example.com`, then install it:

```bash
sudo cp nginx/lira-ai.conf /etc/nginx/sites-available/lira-ai
sudo ln -s /etc/nginx/sites-available/lira-ai /etc/nginx/sites-enabled/lira-ai
sudo nginx -t
sudo systemctl reload nginx
```

Issue certificates after DNS points both names to the VPS:

```bash
sudo certbot --nginx -d app.your-domain.com -d api.your-domain.com
```

Only Nginx should be public. Compose binds the application ports to `127.0.0.1`.

## Updating one service

```bash
cd /opt/LIRA-AI
git pull
./scripts/deploy-backend.sh   # backend changes only
# or
./scripts/deploy-frontend.sh  # frontend changes only
```

## Logs and maintenance

```bash
docker logs -f lira-ai-backend
docker logs -f lira-ai-frontend
./scripts/status.sh
```

Backend application data is bind-mounted from `backend/data`, including ChromaDB persistence. Back up that directory regularly. The Hugging Face/sentence-transformer cache is stored in a named Docker volume.

## Important implementation details

- Backend uses `pip install .`, so dependencies come from the current `pyproject.toml` rather than the repository's older `requirements.txt`.
- Uvicorn runs with one worker because the embedded ChromaDB `PersistentClient` is not multi-worker safe.
- Frontend runs `next build` and `next start`, not the development server.
- The frontend image includes all Node modules because the current `next.config.ts` imports build plugins when Next starts.
